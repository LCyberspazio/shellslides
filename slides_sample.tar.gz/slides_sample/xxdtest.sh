#!/bin/sh

xxd /bin/ls

